# Jalankan di server: PowerShell, dari folder hasil extract zip
# Contoh: .\deploy.ps1 -Project "C:\xampp\htdocs\iseki_marshalling"
param([Parameter(Mandatory=$true)][string]$Project)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path "$Project\artisan")) { throw "Bukan folder Laravel: $Project" }

# 1. Copy file baru/berubah
Copy-Item -Path "$here\files\*" -Destination $Project -Recurse -Force
Write-Host "Copied files."

# 2. Hapus file lama
Get-Content "$here\deleted.txt" | Where-Object { $_ } | ForEach-Object {
  $p = Join-Path $Project ($_ -replace '/', '\')
  if (Test-Path $p) { Remove-Item $p -Force; Write-Host "Deleted $_" }
}
Write-Host "Selesai. Lanjut langkah 3-9 di DEPLOY.txt (.env, composer, migrasi, clear cache)."
